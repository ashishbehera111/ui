// Creation of Angular Module
var app = angular.module('GreetApp',[]);

// Creation of Angular Controller
app.controller('GreetAppCtrl',function() {

});
