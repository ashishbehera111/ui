// Creation of Module
var app  = angular.module('HobbiesApp',[]);

// Creation of Controller
app.controller('HobbiesAppCtrl',function () {
   this.eating = false;
   this.coding = false;
   this.sleeping = false;
});