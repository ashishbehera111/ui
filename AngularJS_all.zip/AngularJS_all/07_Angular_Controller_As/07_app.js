// Creation of module
var app = angular.module('NestedAsApp',[]);

// Creation of Parent Controller
app.controller('ParentAsCtrl',function() {
    this.test = '';
});

// Creation of Child Controller
app.controller('ChildAsCtrl',function() {

});