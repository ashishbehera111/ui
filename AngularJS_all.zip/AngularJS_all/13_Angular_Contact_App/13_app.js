// Creation of angular Module
var app = angular.module('ContactApp',[]);

// Creation of angular Controller
app.controller('ContactAppCtrl',function($scope,$http) {
    $scope.contactList = null;
    $scope.selectedPerson = null;
    $http.get('https://gist.githubusercontent.com/ashishbehera111/71974a091b876808320a5858531cfec4/raw/88d7feb9fe46ce6789428bac817b289a7583277c/db.json').then(function(response) {
        $scope.contactList = response.data.contacts;
    });
    $scope.selectPerson = function(index) {
        $scope.selectedPerson = $scope.contactList[index];
    }

});