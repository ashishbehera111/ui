# JQuery_Development
Usage:

    Please download "JQuery_Stater_Template".
    Copy to your safest folder like D:\ or E:\
    Extract it
    Load it to your Editor
    Follow my classes regularly for Updated and Completed Code.

Thanks for your interest in learning UI Technologies.

Please "Sign Up" to Github and Click on "Follow" Button (below my Profile) for latest updates.

Stay Connected.

Happy Learning :)

Your's NAVEEN SAGGAM
