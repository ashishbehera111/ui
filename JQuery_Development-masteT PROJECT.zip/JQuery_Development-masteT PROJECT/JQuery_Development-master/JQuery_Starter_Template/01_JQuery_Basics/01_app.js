$('#success-button').click(function () {
    $('#success-card').fadeToggle();
    var btn_value = $(this).attr('value');
    console.log(btn_value);
    if (btn_value==='HIDE'){
        $(this).attr('value','show');
    }
    else{
        $(this).attr('value','HIDE');
    }
});